
/*
 * MCreator note: This file will be REGENERATED on each build.
 */
package net.avodarko.epiccraft.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.FlowingFluid;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.ItemBlockRenderTypes;

import net.avodarko.epiccraft.fluid.StillWaterFluid;
import net.avodarko.epiccraft.EpicCraftMod;

public class EpicCraftModFluids {
	public static final DeferredRegister<Fluid> REGISTRY = DeferredRegister.create(BuiltInRegistries.FLUID, EpicCraftMod.MODID);
	public static final DeferredHolder<Fluid, FlowingFluid> STILL_WATER = REGISTRY.register("still_water", () -> new StillWaterFluid.Source());
	public static final DeferredHolder<Fluid, FlowingFluid> FLOWING_STILL_WATER = REGISTRY.register("flowing_still_water", () -> new StillWaterFluid.Flowing());

	@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
	public static class FluidsClientSideHandler {
		@SubscribeEvent
		public static void clientSetup(FMLClientSetupEvent event) {
			ItemBlockRenderTypes.setRenderLayer(STILL_WATER.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(FLOWING_STILL_WATER.get(), RenderType.translucent());
		}
	}
}
