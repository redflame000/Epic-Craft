
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.avodarko.epiccraft.init;

import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.avodarko.epiccraft.client.model.Modelhaufixed;
import net.avodarko.epiccraft.client.model.Modelhau;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD, value = {Dist.CLIENT})
public class EpicCraftModModels {
	@SubscribeEvent
	public static void registerLayerDefinitions(EntityRenderersEvent.RegisterLayerDefinitions event) {
		event.registerLayerDefinition(Modelhaufixed.LAYER_LOCATION, Modelhaufixed::createBodyLayer);
		event.registerLayerDefinition(Modelhau.LAYER_LOCATION, Modelhau::createBodyLayer);
	}
}
