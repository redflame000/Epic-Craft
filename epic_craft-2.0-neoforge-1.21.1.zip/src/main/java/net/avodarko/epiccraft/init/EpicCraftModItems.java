
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.avodarko.epiccraft.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.common.DeferredSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.avodarko.epiccraft.item.YumprimeItem;
import net.avodarko.epiccraft.item.ThickofitItem;
import net.avodarko.epiccraft.item.StillWaterItem;
import net.avodarko.epiccraft.item.NettspendnuggetItem;
import net.avodarko.epiccraft.item.MangoItem;
import net.avodarko.epiccraft.item.LunchlyItem;
import net.avodarko.epiccraft.item.Gucci3rdlegItem;
import net.avodarko.epiccraft.item.FeastablesItem;
import net.avodarko.epiccraft.EpicCraftMod;

public class EpicCraftModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(EpicCraftMod.MODID);
	public static final DeferredItem<Item> THICKOFIT = REGISTRY.register("thickofit", ThickofitItem::new);
	public static final DeferredItem<Item> HOMER_AMONG_US_SPAWN_EGG = REGISTRY.register("homer_among_us_spawn_egg", () -> new DeferredSpawnEggItem(EpicCraftModEntities.HOMER_AMONG_US, -256, -1, new Item.Properties()));
	public static final DeferredItem<Item> LUNCHLY = REGISTRY.register("lunchly", LunchlyItem::new);
	public static final DeferredItem<Item> YUMPRIME = REGISTRY.register("yumprime", YumprimeItem::new);
	public static final DeferredItem<Item> HAWK_TUAH_BLOCK = block(EpicCraftModBlocks.HAWK_TUAH_BLOCK);
	public static final DeferredItem<Item> FEASTABLES = REGISTRY.register("feastables", FeastablesItem::new);
	public static final DeferredItem<Item> STILL_WATER_BUCKET = REGISTRY.register("still_water_bucket", StillWaterItem::new);
	public static final DeferredItem<Item> MANGO = REGISTRY.register("mango", MangoItem::new);
	public static final DeferredItem<Item> MANGOLEAVES = block(EpicCraftModBlocks.MANGOLEAVES);
	public static final DeferredItem<Item> GUCCI_3RDLEG = REGISTRY.register("gucci_3rdleg", Gucci3rdlegItem::new);
	public static final DeferredItem<Item> NETTSPENDNUGGET = REGISTRY.register("nettspendnugget", NettspendnuggetItem::new);

	// Start of user code block custom items
	// End of user code block custom items
	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
