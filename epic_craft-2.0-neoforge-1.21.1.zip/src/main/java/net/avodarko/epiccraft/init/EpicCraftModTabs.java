
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.avodarko.epiccraft.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.avodarko.epiccraft.EpicCraftMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class EpicCraftModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, EpicCraftMod.MODID);
	public static final DeferredHolder<CreativeModeTab, CreativeModeTab> EPIC_ITEMS = REGISTRY.register("epic_items",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.epic_craft.epic_items")).icon(() -> new ItemStack(EpicCraftModItems.LUNCHLY.get())).displayItems((parameters, tabData) -> {
				tabData.accept(EpicCraftModItems.THICKOFIT.get());
				tabData.accept(EpicCraftModItems.LUNCHLY.get());
				tabData.accept(EpicCraftModItems.YUMPRIME.get());
				tabData.accept(EpicCraftModBlocks.HAWK_TUAH_BLOCK.get().asItem());
				tabData.accept(EpicCraftModItems.FEASTABLES.get());
				tabData.accept(EpicCraftModItems.STILL_WATER_BUCKET.get());
				tabData.accept(EpicCraftModItems.MANGO.get());
				tabData.accept(EpicCraftModBlocks.MANGOLEAVES.get().asItem());
				tabData.accept(EpicCraftModItems.GUCCI_3RDLEG.get());
				tabData.accept(EpicCraftModItems.NETTSPENDNUGGET.get());
			}).withSearchBar().build());

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {

			tabData.accept(EpicCraftModItems.HOMER_AMONG_US_SPAWN_EGG.get());

		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {

			tabData.accept(EpicCraftModItems.THICKOFIT.get());

		} else if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {

			tabData.accept(EpicCraftModBlocks.MANGOLEAVES.get().asItem());

		}
	}
}
