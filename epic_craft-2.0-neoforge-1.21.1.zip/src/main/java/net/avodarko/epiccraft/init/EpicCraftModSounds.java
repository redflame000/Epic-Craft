
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.avodarko.epiccraft.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;

import net.avodarko.epiccraft.EpicCraftMod;

public class EpicCraftModSounds {
	public static final DeferredRegister<SoundEvent> REGISTRY = DeferredRegister.create(Registries.SOUND_EVENT, EpicCraftMod.MODID);
	public static final DeferredHolder<SoundEvent, SoundEvent> THICKOFIT = REGISTRY.register("thickofit", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("epic_craft", "thickofit")));
	public static final DeferredHolder<SoundEvent, SoundEvent> HAWKTUAH = REGISTRY.register("hawktuah", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("epic_craft", "hawktuah")));
	public static final DeferredHolder<SoundEvent, SoundEvent> HAWKTUAHSOUND = REGISTRY.register("hawktuahsound", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("epic_craft", "hawktuahsound")));
}
