
/*
 * MCreator note: This file will be REGENERATED on each build.
 */
package net.avodarko.epiccraft.init;

import net.neoforged.neoforge.registries.NeoForgeRegistries;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.fluids.FluidType;

import net.avodarko.epiccraft.fluid.types.StillWaterFluidType;
import net.avodarko.epiccraft.EpicCraftMod;

public class EpicCraftModFluidTypes {
	public static final DeferredRegister<FluidType> REGISTRY = DeferredRegister.create(NeoForgeRegistries.FLUID_TYPES, EpicCraftMod.MODID);
	public static final DeferredHolder<FluidType, FluidType> STILL_WATER_TYPE = REGISTRY.register("still_water", () -> new StillWaterFluidType());
}
