
package net.avodarko.epiccraft.fluid;

import net.neoforged.neoforge.fluids.BaseFlowingFluid;

import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.LiquidBlock;

import net.avodarko.epiccraft.init.EpicCraftModItems;
import net.avodarko.epiccraft.init.EpicCraftModFluids;
import net.avodarko.epiccraft.init.EpicCraftModFluidTypes;
import net.avodarko.epiccraft.init.EpicCraftModBlocks;

public abstract class StillWaterFluid extends BaseFlowingFluid {
	public static final BaseFlowingFluid.Properties PROPERTIES = new BaseFlowingFluid.Properties(() -> EpicCraftModFluidTypes.STILL_WATER_TYPE.get(), () -> EpicCraftModFluids.STILL_WATER.get(), () -> EpicCraftModFluids.FLOWING_STILL_WATER.get())
			.explosionResistance(100f).bucket(() -> EpicCraftModItems.STILL_WATER_BUCKET.get()).block(() -> (LiquidBlock) EpicCraftModBlocks.STILL_WATER.get());

	private StillWaterFluid() {
		super(PROPERTIES);
	}

	public static class Source extends StillWaterFluid {
		public int getAmount(FluidState state) {
			return 8;
		}

		public boolean isSource(FluidState state) {
			return true;
		}
	}

	public static class Flowing extends StillWaterFluid {
		protected void createFluidStateDefinition(StateDefinition.Builder<Fluid, FluidState> builder) {
			super.createFluidStateDefinition(builder);
			builder.add(LEVEL);
		}

		public int getAmount(FluidState state) {
			return state.getValue(LEVEL);
		}

		public boolean isSource(FluidState state) {
			return false;
		}
	}
}
