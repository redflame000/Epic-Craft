
package net.avodarko.epiccraft.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

import net.avodarko.epiccraft.entity.HomerAmongUsEntity;
import net.avodarko.epiccraft.client.model.Modelhaufixed;

public class HomerAmongUsRenderer extends MobRenderer<HomerAmongUsEntity, Modelhaufixed<HomerAmongUsEntity>> {
	public HomerAmongUsRenderer(EntityRendererProvider.Context context) {
		super(context, new Modelhaufixed(context.bakeLayer(Modelhaufixed.LAYER_LOCATION)), 0.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(HomerAmongUsEntity entity) {
		return ResourceLocation.parse("epic_craft:textures/entities/homeramongus.png");
	}
}
