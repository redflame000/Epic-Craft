
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.avodarko.epiccraft.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.Block;

import net.avodarko.epiccraft.block.StillWaterBlock;
import net.avodarko.epiccraft.block.MangoleavesBlock;
import net.avodarko.epiccraft.block.HawkTuahBlockBlock;
import net.avodarko.epiccraft.EpicCraftMod;

public class EpicCraftModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(EpicCraftMod.MODID);
	public static final DeferredBlock<Block> HAWK_TUAH_BLOCK = REGISTRY.register("hawk_tuah_block", HawkTuahBlockBlock::new);
	public static final DeferredBlock<Block> STILL_WATER = REGISTRY.register("still_water", StillWaterBlock::new);
	public static final DeferredBlock<Block> MANGOLEAVES = REGISTRY.register("mangoleaves", MangoleavesBlock::new);
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
